import { app } from '../fonoaudio-server.js';
export default app;